const libros = [
    {
      image: 'https://picsum.photos/200/300?image=1005',
      title: 'Título del Libro 1',
      categories: 'Categoría 1, Categoría 2',
      description: 'Esta es una breve sinopsis del libro 1.',
      pdfUrl: 'https://drive.google.com/file/d/1ZIjtZtgAFBVdK-m5Mes9JMXg7J0OUzAs/view',
    },
    {
      image: 'https://picsum.photos/200/300?image=1006',
      title: 'Título del Libro 2',
      categories: 'Categoría 3, Categoría 4',
      description: 'Esta es una breve sinopsis del libro 2.',
      pdfUrl: 'https://drive.google.com/file/d/1ZIjtZtgAFBVdK-m5Mes9JMXg7J0OUzAs/view',
    },
    {
        image: 'https://picsum.photos/200/300?image=1008',
        title: 'Título del Libro 3',
        categories: 'Categoría 5, Categoría 6',
        description: 'Esta es una breve sinopsis del libro 3.',
        pdfUrl: 'https://drive.google.com/file/d/1ZIjtZtgAFBVdK-m5Mes9JMXg7J0OUzAs/view',
      },
  ];
  
  export default libros;