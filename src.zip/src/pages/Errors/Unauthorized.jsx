import React from "react";

export default function Unauthorized() {
  return (
    <div>
      <h1>Acceso Denegado</h1>
      <p>No tienes permiso para acceder a esta página.</p>
    </div>
  );
}
