import React from 'react';
import './Loader.css'; 

const Load = () => {
  return <div className="custom-loader"></div>;
};

export default Load;
